require 'test_helper'

class CreateCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
