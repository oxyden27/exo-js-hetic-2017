require 'test_helper'

class CreateAnnonceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
