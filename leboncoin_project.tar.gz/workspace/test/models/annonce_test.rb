require 'test_helper'

class AnnonceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
